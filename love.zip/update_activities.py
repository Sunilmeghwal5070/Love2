import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("val factory = LoveViewModelFactory(repository, tts)", "val prefs = com.example.data.PreferencesManager(this)\n    val factory = LoveViewModelFactory(prefs, repository, tts)")

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("val factory = LoveViewModelFactory(repository, tts)", "val prefs = com.example.data.PreferencesManager(this)\n        val factory = LoveViewModelFactory(prefs, repository, tts)")

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

