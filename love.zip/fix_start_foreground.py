import re

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'r') as f:
    content = f.read()

content = content.replace("startForeground(1, createNotification())", """if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(1, createNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, createNotification())
        }""")

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'w') as f:
    f.write(content)

