import re

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'r') as f:
    content = f.read()

content = content.replace("class LoveBackgroundService : Service() {", """class LoveBackgroundService : Service() {
    companion object {
        var isOverlayActive = false
    }""")

content = content.replace("if (!isListening) {", "if (!isListening && !isOverlayActive) {")

start_listening = """    private fun startListening() {
        if (isOverlayActive) return
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {"""
content = content.replace("    private fun startListening() {\n        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {", start_listening)

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content2 = f.read()

content2 = content2.replace("super.onCreate(savedInstanceState)", "super.onCreate(savedInstanceState)\n        com.example.assistant.LoveBackgroundService.isOverlayActive = true")
content2 = content2.replace("super.onDestroy()", "com.example.assistant.LoveBackgroundService.isOverlayActive = false\n        // Optionally tell service to resume\n        startService(Intent(this, com.example.assistant.LoveBackgroundService::class.java))\n        super.onDestroy()")

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content2)

