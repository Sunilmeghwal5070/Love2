import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("tts?.stop()\n        tts?.shutdown()", "// tts?.stop()\n        // tts?.shutdown()")

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

