import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

replacement = """
                override fun onError(error: Int) {
                    val isActiveMode = viewModel.isListening.value
                    if (isActiveMode) {
                        viewModel.stopListening(null)
                        finish()
                    }
                }
"""

content = re.sub(r'override fun onError\(error: Int\) \{.*?viewModel\.stopListening\(null\)\n\s*\}\n\s*\}', replacement.strip(), content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

