import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

new_handle = """  private fun handleAssistantIntent(intent: android.content.Intent?) {
      val fromAssistant = intent?.getBooleanExtra("from_assistant", false) == true
      val isAssistAction = intent?.action == android.content.Intent.ACTION_ASSIST
      val fromHotword = intent?.getBooleanExtra("from_hotword", false) == true
      if (fromAssistant || isAssistAction || fromHotword) {
          viewModel.toggleGlobalPopup(true)
          if (fromHotword) {
              tts?.speak("Yes Boss?", TextToSpeech.QUEUE_FLUSH, null, "hotword_reply")
          }
          viewModel.startListening()
      }
  }"""

content = re.sub(r'private fun handleAssistantIntent.*?\}', new_handle, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

