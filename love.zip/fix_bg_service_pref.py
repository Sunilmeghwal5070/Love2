import re

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'r') as f:
    content = f.read()

replacement = """
    private fun startListening() {
        if (isOverlayActive) return
        val prefs = com.example.data.PreferencesManager(this)
        if (!prefs.hotwordDetection) return
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
"""

content = content.replace("""
    private fun startListening() {
        if (isOverlayActive) return
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {""", replacement)

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'w') as f:
    f.write(content)

