import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

replacement = """
            LaunchedEffect(actionExecuting) {
                if (actionExecuting != null) {
                    val targetApp = actionExecuting!!
                    try {
                        val packageManager = packageManager
                        var intent = packageManager.getLaunchIntentForPackage(targetApp)
                        
                        // Try matching by app name
                        if (intent == null) {
                            val packages = packageManager.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
                            for (packageInfo in packages) {
                                val label = packageManager.getApplicationLabel(packageInfo).toString()
                                if (label.equals(targetApp, ignoreCase = true)) {
                                    intent = packageManager.getLaunchIntentForPackage(packageInfo.packageName)
                                    break
                                }
                            }
                        }
                        
                        // Fallback common names
                        if (intent == null) {
                            val lower = targetApp.lowercase()
                            val pack = when {
                                lower.contains("youtube") -> "com.google.android.youtube"
                                lower.contains("whatsapp") -> "com.whatsapp"
                                lower.contains("instagram") -> "com.instagram.android"
                                lower.contains("facebook") -> "com.facebook.katana"
                                lower.contains("camera") -> {
                                    val camIntent = android.content.Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                                    camIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    try {
                                        startActivity(camIntent)
                                        return@LaunchedEffect
                                    } catch (e: Exception) { null }
                                    "com.android.camera2"
                                }
                                else -> null
                            }
                            if (pack != null) {
                                intent = packageManager.getLaunchIntentForPackage(pack)
                            }
                        }

                        if (intent != null) {
                            startActivity(intent)
                        } else {
                            val intentSearch = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://play.google.com/store/search?q=$targetApp")
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intentSearch)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    } finally {
                        viewModel.clearAction()
                        finish()
                    }
                }
            }
"""

content = re.sub(r'LaunchedEffect\(actionExecuting\) \{.*?\}(?=\n\n            val infiniteTransition)', replacement.strip(), content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

