import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Replace the onError logic
new_on_error = """            override fun onError(error: Int) {
                val isActiveMode = viewModel.isListening.value
                if (isActiveMode) {
                    if (error != android.speech.SpeechRecognizer.ERROR_CLIENT) {
                        tts?.speak("I didn't quite catch that, boss.", TextToSpeech.QUEUE_FLUSH, null, null)
                    }
                    viewModel.stopListening(null)
                }
            }"""

content = re.sub(r'override fun onError\(error: Int\) \{.*?\}(?=\s*override fun onResults)', new_on_error, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

