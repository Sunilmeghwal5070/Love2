import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Add service start in onCreate
service_start = """    tts = TextToSpeech(this, this)
    
    // Start background hotword service
    if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
        val serviceIntent = android.content.Intent(this, com.example.assistant.LoveBackgroundService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }"""

content = content.replace("tts = TextToSpeech(this, this)", service_start)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

