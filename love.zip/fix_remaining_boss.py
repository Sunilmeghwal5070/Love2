import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace('tts?.speak("Hello boss"', 'tts?.speak("Hello ${prefs.userName}"')
content = content.replace('tts?.speak("Yes Boss?"', 'tts?.speak("Yes ${prefs.userName}?"')

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/components/LoveAssistantPopup.kt', 'r') as f:
    content = f.read()

content = content.replace('"Hi Boss, Ask Love"', '"Hi, Ask Me"')

with open('app/src/main/java/com/example/ui/components/LoveAssistantPopup.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('text = "Boss."', 'text = "${com.example.data.PreferencesManager(context).userName}."')

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)

