import re

with open('app/src/main/java/com/example/ui/LoveViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace("class LoveViewModel(", "class LoveViewModel(\n    private val prefs: com.example.data.PreferencesManager,\n")

content = content.replace("val fillers = listOf(\"Ek second boss...\", \"Abhi dekhta hoon boss...\", \"Ji boss...\", \"Processing...\")", """
        val userName = prefs.userName
        val assistantName = prefs.wakeWord
        val fillers = listOf("Ek second $userName...", "Abhi dekhta hoon $userName...", "Ji $userName...", "Processing...")
""")

content = content.replace("val systemInstructionText = \"You are a personal AI Voice Assistant named Love, similar to Jarvis. The user likes to be called 'Boss'. Keep responses EXTREMELY short and concise (max 1 or 2 sentences), so it's fast to read aloud. If the user speaks in Hindi, reply in Hinglish so standard TTS can read it. If the user asks to open an app (e.g., WhatsApp, YouTube, Camera) or perform an action, you MUST output a JSON block at the very end of your response exactly like this: `{\\\"action\\\": \\\"open_app\\\", \\\"target\\\": \\\"AppName\\\"}`. Before the JSON block, you MUST say something acknowledging the action like 'Yes Boss, opening AppName.' Do NOT include markdown blocks around the JSON.\"", """
                val systemInstructionText = "You are a personal AI Voice Assistant named $assistantName, similar to Jarvis. The user likes to be called '$userName'. Keep responses EXTREMELY short and concise (max 1 or 2 sentences), so it's fast to read aloud. If the user speaks in Hindi, reply in Hinglish so standard TTS can read it. If the user asks to open an app (e.g., WhatsApp, YouTube, Camera) or perform an action, you MUST output a JSON block at the very end of your response exactly like this: `{\\"action\\": \\"open_app\\", \\"target\\": \\"AppName\\"}`. Before the JSON block, you MUST say something acknowledging the action like 'Yes $userName, opening AppName.' Do NOT include markdown blocks around the JSON."
""")

content = content.replace("Sorry boss", "Sorry $userName")
content = content.replace("Boss, network", "$userName, network")

with open('app/src/main/java/com/example/ui/LoveViewModel.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/LoveViewModelFactory.kt', 'r') as f:
    content = f.read()

content = content.replace("class LoveViewModelFactory(", "class LoveViewModelFactory(\n    private val prefs: com.example.data.PreferencesManager,\n")
content = content.replace("return LoveViewModel(repository, tts)", "return LoveViewModel(prefs, repository, tts)")

with open('app/src/main/java/com/example/ui/LoveViewModelFactory.kt', 'w') as f:
    f.write(content)

