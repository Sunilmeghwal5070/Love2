import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

replacement = """
  override fun onResume() {
      super.onResume()
      isResumedState = true
      
      // Try starting service if permissions are granted
      val prefs = com.example.data.PreferencesManager(this)
      if (prefs.hotwordDetection && androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED && android.provider.Settings.canDrawOverlays(this)) {
          val serviceIntent = android.content.Intent(this, com.example.assistant.LoveBackgroundService::class.java)
          if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
              try {
                  startForegroundService(serviceIntent)
              } catch (e: Exception) { e.printStackTrace() }
          } else {
              try {
                  startService(serviceIntent)
              } catch (e: Exception) { e.printStackTrace() }
          }
      }
  }
"""

content = re.sub(r'override fun onResume\(\) \{.*?\}', replacement.strip(), content, flags=re.DOTALL)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

