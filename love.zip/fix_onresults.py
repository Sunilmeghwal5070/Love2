import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

new_on_results = """            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.lowercase() ?: ""
                val isActiveMode = viewModel.isListening.value
                if (isActiveMode) {
                    if (text.isNotEmpty()) {
                        viewModel.stopListening(text)
                    } else {
                        tts?.speak("I didn't quite catch that, boss.", TextToSpeech.QUEUE_FLUSH, null, null)
                        viewModel.stopListening(null)
                    }
                }
            }"""

content = re.sub(r'override fun onResults\(results: Bundle\?\) \{.*?\}(?=\s*override fun onPartialResults)', new_on_results, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

