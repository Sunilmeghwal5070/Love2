import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace(
    "SettingsScreen(onNavigateBack = { navController.popBackStack() })",
    "SettingsScreen(onNavigateBack = { navController.popBackStack() }, onNavigateToPermissions = { navController.navigate(PermissionsRoute) })"
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("GlassButton(onClick = onNavigateToPermissions, icon = Icons.Default.Security)", "")
content = content.replace("Spacer(modifier = Modifier.width(8.dp))", "", 1) # remove the spacer after it

with open('app/src/main/java/com/example/ui/screens/HomeScreen.kt', 'w') as f:
    f.write(content)
