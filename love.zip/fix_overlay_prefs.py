import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("private var speechRecognizer: android.speech.SpeechRecognizer? = null", "private var speechRecognizer: android.speech.SpeechRecognizer? = null\n    private lateinit var prefs: com.example.data.PreferencesManager")

content = content.replace("        val prefs = com.example.data.PreferencesManager(this)\n        val factory = LoveViewModelFactory(prefs, repository, tts)", "        prefs = com.example.data.PreferencesManager(this)\n        val factory = LoveViewModelFactory(prefs, repository, tts)")

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

