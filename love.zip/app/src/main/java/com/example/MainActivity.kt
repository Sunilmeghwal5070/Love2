package com.example

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.Modifier
import androidx.compose.material.icons.filled.Mic
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.ChatRepository
import com.example.ui.LoveViewModel
import com.example.ui.LoveViewModelFactory
import com.example.ui.navigation.HistoryRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.SettingsRoute
import com.example.ui.navigation.PermissionsRoute
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import java.util.Locale

import androidx.compose.foundation.layout.height
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
  private var tts: TextToSpeech? = null
  private lateinit var viewModel: LoveViewModel
  private var speechRecognizer: android.speech.SpeechRecognizer? = null
  private var isResumedState = false

  override fun onResume() {
      super.onResume()
      isResumedState = true
      com.example.assistant.LoveBackgroundService.isMainActivityActive = true
      com.example.assistant.LoveBackgroundService.stopListeningIfRunning()

      
      // Try starting service if permissions are granted
      val prefs = com.example.data.PreferencesManager(this)
      if (prefs.hotwordDetection && androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED && android.provider.Settings.canDrawOverlays(this)) {
          val serviceIntent = android.content.Intent(this, com.example.assistant.LoveBackgroundService::class.java)
          if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
              try {
                  startForegroundService(serviceIntent)
              } catch (e: Exception) { e.printStackTrace() }
          } else {
              try {
                  startService(serviceIntent)
              } catch (e: Exception) { e.printStackTrace() }
          }
      }
  }
  override fun onPause() {
      super.onPause()
      isResumedState = false
      speechRecognizer?.stopListening()
      speechRecognizer?.cancel()
      com.example.assistant.LoveBackgroundService.isMainActivityActive = false
      try {
          startService(android.content.Intent(this, com.example.assistant.LoveBackgroundService::class.java))
      } catch (e: Exception) {}
  }

  private fun startInternalListening() {
      if (speechRecognizer == null || !isResumedState) return
      if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
          try {
              speechRecognizer?.cancel()
          } catch (e: Exception) {
              e.printStackTrace()
          }
          val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
              putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
          }
          try {
              speechRecognizer?.startListening(intent)
          } catch (e: Exception) {
              e.printStackTrace()
          }
      }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

        tts = TextToSpeech(this, this)
    
    // Start background hotword service
    if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
        val serviceIntent = android.content.Intent(this, com.example.assistant.LoveBackgroundService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
    }
    
    // Initialize Speech Recognizer
    if (android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
        speechRecognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
                        override fun onError(error: Int) {
                if (error == android.speech.SpeechRecognizer.ERROR_CLIENT) {
                    return // Ignore client errors like cancel
                }
                val isActiveMode = viewModel.isListening.value
                if (isActiveMode) {
                    viewModel.stopListening(null)
                }
            }
                        override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.lowercase() ?: ""
                val isActiveMode = viewModel.isListening.value
                if (isActiveMode) {
                    if (text.isNotEmpty()) {
                        viewModel.stopListening(text)
                    } else {
                        
                        viewModel.stopListening(null)
                    }
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    val database = Room.databaseBuilder(
        applicationContext,
        AppDatabase::class.java, "love-database"
    ).build()
    val repository = ChatRepository(database.chatDao())
    val prefs = com.example.data.PreferencesManager(this)
    val factory = LoveViewModelFactory(prefs, repository, tts)
    
    viewModel = androidx.lifecycle.ViewModelProvider(this, factory)[LoveViewModel::class.java]
    
    handleAssistantIntent(intent)

    setContent {
      MyApplicationTheme {
        val permissionsToRequest = arrayOf(
            android.Manifest.permission.RECORD_AUDIO
        )
        
        val permissionsState = androidx.compose.runtime.remember {
            androidx.compose.runtime.mutableStateOf(
                androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED 
            )
        }

        val multiplePermissionsLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            permissionsState.value = permissions[android.Manifest.permission.RECORD_AUDIO] == true
        }

        androidx.compose.runtime.LaunchedEffect(Unit) {
            if (!permissionsState.value) {
                multiplePermissionsLauncher.launch(permissionsToRequest)
            }
        }
        
        if (!permissionsState.value) {
            // Show a blocked screen until permissions are granted
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                androidx.compose.foundation.layout.Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                    androidx.compose.material3.Text("Permissions required to use the app.", style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                    androidx.compose.foundation.layout.Spacer(modifier = Modifier.height(16.dp))
                    androidx.compose.material3.Button(onClick = { multiplePermissionsLauncher.launch(permissionsToRequest) }) {
                        androidx.compose.material3.Text("Grant Permissions")
                    }
                }
            }
            return@MyApplicationTheme
        }

        val navController = rememberNavController()
        val showGlobalPopup by viewModel.showGlobalPopup.collectAsStateWithLifecycle()
        val isListening by viewModel.isListening.collectAsStateWithLifecycle()
        val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
        val actionExecuting by viewModel.actionExecuting.collectAsStateWithLifecycle()
        
        val permissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                // If it was just granted and we are supposed to be listening, we could start here, 
                // but the user might need to press the mic again. 
                // Let's just let them press it again for simplicity, or we can toggle it off and on.
                viewModel.stopListening(null)
                android.widget.Toast.makeText(this@MainActivity, "Tap mic again to speak", android.widget.Toast.LENGTH_SHORT).show()
            } else {
                viewModel.stopListening(null)
            }
        }

        androidx.compose.runtime.LaunchedEffect(isListening, permissionsState.value) {
            if (permissionsState.value) {
                if (isListening) {
                    startInternalListening()
                } else {
                    speechRecognizer?.stopListening()
                    speechRecognizer?.cancel()
                }
            }
        }
        
        androidx.compose.runtime.LaunchedEffect(Unit) {
            viewModel.actionTrigger.collect { targetApp ->
                // Basic implementation to launch an app by name
                try {
                    viewModel.toggleGlobalPopup(true)
                    kotlinx.coroutines.delay(3000) // Allow TTS to finish speaking before opening app
                    var launched = false
                    val pm = packageManager
                    
                    // Fast path for common apps
                    val commonApps = mapOf(
                        "whatsapp" to "com.whatsapp",
                        "youtube" to "com.google.android.youtube",
                        "chrome" to "com.android.chrome",
                        "camera" to "com.android.camera2", // varies by device
                        "calculator" to "com.google.android.calculator"
                    )
                    
                    val lowerTarget = targetApp.lowercase().trim()
                    if (commonApps.containsKey(lowerTarget)) {
                        val packageName = commonApps[lowerTarget]!!
                        val launchIntent = pm.getLaunchIntentForPackage(packageName)
                        if (launchIntent != null) {
                            launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launchIntent)
                            launched = true
                        }
                    }
                    
                    if (!launched) {
                        val packages = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)
                        for (packageInfo in packages) {
                            val appName = pm.getApplicationLabel(packageInfo).toString()
                            if (appName.equals(targetApp, ignoreCase = true) || appName.contains(targetApp, ignoreCase = true)) {
                                val launchIntent = pm.getLaunchIntentForPackage(packageInfo.packageName)
                                if (launchIntent != null) {
                                    launchIntent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    startActivity(launchIntent)
                                    launched = true
                                    break
                                }
                            }
                        }
                    }
                    
                    if (!launched) {
                        // Fallback: search play store
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("market://search?q=$targetApp")
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intent)
                        } catch (e: android.content.ActivityNotFoundException) {
                            val webIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://play.google.com/store/search?q=$targetApp")
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(webIntent)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                } finally {
                    viewModel.clearAction()
                    viewModel.toggleGlobalPopup(false)
                }
            }
        }

        Box(modifier = Modifier.fillMaxSize()) {
            NavHost(navController = navController, startDestination = HomeRoute) {
                composable<HomeRoute> {
                    val history by viewModel.chatHistory.collectAsStateWithLifecycle()
                    HomeScreen(
                        onNavigateToSettings = { navController.navigate(SettingsRoute) },
                        onNavigateToHistory = { navController.navigate(HistoryRoute) },
                        isListening = isListening,
                        isProcessing = isProcessing,
                        onStartListening = { viewModel.startListening() },
                        onStopListening = { query -> viewModel.stopListening(query) },
                        latestMessage = history.lastOrNull(),
                        onTriggerPopup = { viewModel.toggleGlobalPopup(true) }
                    )
                }
                composable<SettingsRoute> {
                    SettingsScreen(onNavigateBack = { navController.popBackStack() }, onNavigateToPermissions = { navController.navigate(PermissionsRoute) })
                }
                composable<HistoryRoute> {
                    val history by viewModel.chatHistory.collectAsStateWithLifecycle()
                    HistoryScreen(
                        onNavigateBack = { navController.popBackStack() },
                        history = history
                    )
                }
                composable<PermissionsRoute> {
                    PermissionsScreen(onNavigateBack = { navController.popBackStack() })
                }
            }
            
            // Global floating button to simulate hotword "Hey Love"
            if (!showGlobalPopup) {
                androidx.compose.material3.FloatingActionButton(
                    onClick = { 
                        viewModel.toggleGlobalPopup(true)
                        viewModel.startListening()
                    },
                    modifier = Modifier
                        .align(androidx.compose.ui.Alignment.BottomEnd)
                        .padding(16.dp),
                    containerColor = androidx.compose.ui.graphics.Color(0xFFFF6FA5)
                ) {
                    androidx.compose.material3.Icon(
                        imageVector = androidx.compose.material.icons.Icons.Default.Mic,
                        contentDescription = "Simulate Hey Love",
                        tint = androidx.compose.ui.graphics.Color.White
                    )
                }
            }
            
            // Edge Glow Effect
            if (isListening) {
                val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
                val glowAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 0.8f,
                    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                        animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                        repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
                    ), label = "glowAlpha"
                )
                
                Box(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp)) {
                    // Left Edge
                    Box(modifier = Modifier
                        .align(androidx.compose.ui.Alignment.CenterStart)
                        .width(16.dp)
                        .fillMaxHeight()
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                colors = listOf(
                                    androidx.compose.ui.graphics.Color(0xFFFF6FA5).copy(alpha = glowAlpha),
                                    androidx.compose.ui.graphics.Color.Transparent
                                )
                            )
                        )
                    )
                    // Right Edge
                    Box(modifier = Modifier
                        .align(androidx.compose.ui.Alignment.CenterEnd)
                        .width(16.dp)
                        .fillMaxHeight()
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                colors = listOf(
                                    androidx.compose.ui.graphics.Color.Transparent,
                                    androidx.compose.ui.graphics.Color(0xFFFF6FA5).copy(alpha = glowAlpha)
                                )
                            )
                        )
                    )
                }
            }

            com.example.ui.components.LoveAssistantPopup(
                isVisible = showGlobalPopup,
                isListening = isListening,
                isProcessing = isProcessing,
                actionExecuting = actionExecuting,
                onMicClick = { 
                    if (isListening) viewModel.stopListening(null)
                    else {
                        // Will need to be connected to the speech recognizer
                        viewModel.startListening()
                    }
                },
                onClose = { viewModel.toggleGlobalPopup(false) },
                modifier = Modifier.align(androidx.compose.ui.Alignment.BottomCenter)
            )
        }
      }
    }
  }

  override fun onInit(status: Int) {
      if (status == TextToSpeech.SUCCESS) {
          val result = tts?.setLanguage(Locale.forLanguageTag("hi-IN"))
          if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
              tts?.setLanguage(Locale.ENGLISH)
          }
          
          try {
              // Try to find and set a higher quality or network voice for a more premium, less robotic sound
              val voices = tts?.voices
              if (voices != null) {
                  val targetLang = tts?.language?.language ?: "en"
                  val premiumVoice = voices.find { 
                      it.locale.language == targetLang && it.isNetworkConnectionRequired 
                  } ?: voices.find { 
                      it.locale.language == targetLang && it.quality >= android.speech.tts.Voice.QUALITY_HIGH 
                  } ?: voices.find {
                      it.locale.language == targetLang && it.name.contains("network", ignoreCase = true)
                  }
                  
                  if (premiumVoice != null) {
                      tts?.voice = premiumVoice
                  }
              }
          } catch (e: Exception) {
              e.printStackTrace()
          }
          
          // Adjust pitch and rate slightly for a more natural, conversational tone
          tts?.setPitch(1.0f)
          tts?.setSpeechRate(0.95f)

          val prefs = com.example.data.PreferencesManager(this)
          tts?.speak("Hello ${prefs.userName}", TextToSpeech.QUEUE_FLUSH, null, null)
      }
  }

  override fun onNewIntent(intent: android.content.Intent) {
      super.onNewIntent(intent)
      setIntent(intent)
      handleAssistantIntent(intent)
  }

    private fun handleAssistantIntent(intent: android.content.Intent?) {
      val fromAssistant = intent?.getBooleanExtra("from_assistant", false) == true
      val isAssistAction = intent?.action == android.content.Intent.ACTION_ASSIST
      val fromHotword = intent?.getBooleanExtra("from_hotword", false) == true
      if (fromAssistant || isAssistAction || fromHotword) {
          viewModel.toggleGlobalPopup(true)
          if (fromHotword) {
              val prefs = com.example.data.PreferencesManager(this)
              tts?.speak("Yes ${prefs.userName}?", TextToSpeech.QUEUE_FLUSH, null, "hotword_reply")
          }
          viewModel.startListening()
      }
  }

  override fun onDestroy() {
      speechRecognizer?.destroy()
      tts?.stop()
      tts?.shutdown()
      super.onDestroy()
  }
}
