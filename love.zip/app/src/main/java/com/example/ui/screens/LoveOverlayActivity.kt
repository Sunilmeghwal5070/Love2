package com.example.ui.screens

import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.Room
import com.example.data.AppDatabase
import com.example.data.ChatRepository
import com.example.ui.LoveViewModel
import com.example.ui.LoveViewModelFactory
import com.example.ui.components.LoveAssistantPopup
import java.util.Locale

class LoveOverlayActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var viewModel: LoveViewModel
    private var speechRecognizer: android.speech.SpeechRecognizer? = null
    private lateinit var prefs: com.example.data.PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.assistant.LoveBackgroundService.isOverlayActivityActive = true
        com.example.assistant.LoveBackgroundService.stopListeningIfRunning()
        
        tts = TextToSpeech(this.applicationContext, this)
        
        if (android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    if (error == android.speech.SpeechRecognizer.ERROR_CLIENT) {
                        return // Ignore client errors
                    }
                    val isActiveMode = viewModel.isListening.value
                    if (isActiveMode) {
                        viewModel.stopListening(null)
                        finish()
                    }
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.lowercase() ?: ""
                    val isActiveMode = viewModel.isListening.value
                    if (isActiveMode) {
                        if (text.isNotEmpty()) {
                            viewModel.stopListening(text)
                        } else {
                            viewModel.stopListening(null)
                            finish()
                        }
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "love-database"
        ).build()
        val repository = ChatRepository(database.chatDao())
        prefs = com.example.data.PreferencesManager(this)
        val factory = LoveViewModelFactory(prefs, repository, tts)
        viewModel = ViewModelProvider(this, factory)[LoveViewModel::class.java]

        setContent {
            val isListening by viewModel.isListening.collectAsStateWithLifecycle()
            val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
            val actionExecuting by viewModel.actionExecuting.collectAsStateWithLifecycle()

            LaunchedEffect(actionExecuting) {
                if (actionExecuting != null) {
                    val targetApp = actionExecuting
                    try {
                        kotlinx.coroutines.delay(3000) // Allow TTS to finish speaking first
                        val pm = packageManager
                        val lowerTarget = targetApp!!.lowercase().trim()
                        var intent: android.content.Intent? = null
                        
                        if (lowerTarget.contains("camera")) {
                            intent = android.content.Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                        } else if (lowerTarget.contains("dialer") || lowerTarget.contains("phone")) {
                            intent = android.content.Intent(android.content.Intent.ACTION_DIAL)
                        } else {
                            val commonApps = mapOf(
                                "whatsapp" to "com.whatsapp",
                                "youtube" to "com.google.android.youtube",
                                "chrome" to "com.android.chrome",
                                "calculator" to "com.google.android.calculator",
                                "settings" to "com.android.settings",
                                "maps" to "com.google.android.apps.maps",
                                "gmail" to "com.google.android.gm",
                                "facebook" to "com.facebook.katana",
                                "instagram" to "com.instagram.android"
                            )
                            var matchedPackage = commonApps[lowerTarget]
                            if (matchedPackage == null) {
                                for ((key, pkg) in commonApps) {
                                    if (lowerTarget.contains(key) || key.contains(lowerTarget)) {
                                        matchedPackage = pkg
                                        break
                                    }
                                }
                            }
                            
                            val targetPkg = matchedPackage ?: targetApp
                            intent = pm.getLaunchIntentForPackage(targetPkg)
                        }
                        
                        if (intent != null) {
                            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                        } else {
                            val intentSearch = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://play.google.com/store/search?q=$targetApp")
                                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            startActivity(intentSearch)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    } finally {
                        viewModel.clearAction()
                        finish()
                    }
                }
            }


            val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
            val glowAlpha by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 0.8f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                    repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
                ), label = "glowAlpha"
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Transparent)
            ) {
                // Left Edge
                Box(modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(16.dp)
                    .fillMaxHeight()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFFFF6FA5).copy(alpha = glowAlpha),
                                Color.Transparent
                            )
                        )
                    )
                )
                // Right Edge
                Box(modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(16.dp)
                    .fillMaxHeight()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFFFF6FA5).copy(alpha = glowAlpha)
                            )
                        )
                    )
                )

                LoveAssistantPopup(

                    isVisible = true,
                    isListening = isListening,
                    isProcessing = isProcessing,
                    actionExecuting = actionExecuting,
                    onMicClick = {
                        if (isListening) viewModel.stopListening(null)
                        else startInternalListening()
                    },
                    onClose = { finish() },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }
    }

    private fun startInternalListening() {
        if (speechRecognizer == null) return
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try {
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            }
            try {
                speechRecognizer?.startListening(intent)
                viewModel.startListening()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.forLanguageTag("hi-IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.ENGLISH)
            }
            try {
                val voices = tts?.voices
                if (voices != null) {
                    val targetLang = tts?.language?.language ?: "en"
                    val premiumVoice = voices.find {
                        it.locale.language == targetLang && it.isNetworkConnectionRequired
                    } ?: voices.find {
                        it.locale.language == targetLang && it.quality >= android.speech.tts.Voice.QUALITY_HIGH
                    } ?: voices.find {
                        it.locale.language == targetLang && it.name.contains("network", ignoreCase = true)
                    }
                    if (premiumVoice != null) {
                        tts?.voice = premiumVoice
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            tts?.setPitch(1.0f)
            tts?.setSpeechRate(0.95f)
            
            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "overlay_ready") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            startInternalListening()
                        }
                    } else if (utteranceId == "love_response" || utteranceId == "love_error") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            if (viewModel.actionExecuting.value == null) {
                                finish()
                            }
                        }
                    }
                }
                override fun onError(utteranceId: String?) {
                    if (utteranceId == "overlay_ready") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            startInternalListening()
                        }
                    }
                }
            })
            
            // Auto start listening on open
            tts?.speak("Yes ${prefs.userName}?", TextToSpeech.QUEUE_FLUSH, null, "overlay_ready")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        // tts?.stop()
        // tts?.shutdown()
        com.example.assistant.LoveBackgroundService.isOverlayActivityActive = false
        // Optionally tell service to resume
        startService(Intent(this, com.example.assistant.LoveBackgroundService::class.java))
        super.onDestroy()
    }
}
