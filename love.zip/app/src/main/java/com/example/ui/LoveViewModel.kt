package com.example.ui

import android.speech.tts.TextToSpeech
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.ChatRepository
import com.example.data.RetrofitClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import kotlinx.coroutines.flow.asSharedFlow

class LoveViewModel(
    private val prefs: com.example.data.PreferencesManager,

    private val repository: ChatRepository,
    private val tts: TextToSpeech?
) : ViewModel() {

    val chatHistory = repository.allMessages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _showGlobalPopup = MutableStateFlow(false)
    val showGlobalPopup: StateFlow<Boolean> = _showGlobalPopup

    private val _actionExecuting = MutableStateFlow<String?>(null)
    val actionExecuting: StateFlow<String?> = _actionExecuting

    private val _actionTrigger = kotlinx.coroutines.flow.MutableSharedFlow<String>()
    val actionTrigger = _actionTrigger.asSharedFlow()

    fun toggleGlobalPopup(show: Boolean) {
        _showGlobalPopup.value = show
    }

    fun clearAction() {
        _actionExecuting.value = null
    }

    fun startListening() {
        _isListening.value = true
    }

    fun stopListening(query: String? = null) {
        _isListening.value = false
        if (!query.isNullOrEmpty()) {
            processUserQuery(query)
        } else {
            val userName = prefs.userName
            tts?.speak("Boss $userName, mujhe sunai nahin diya, kya aap wapas bolenge?", TextToSpeech.QUEUE_FLUSH, null, "love_error")
            viewModelScope.launch {
                kotlinx.coroutines.delay(4000)
                _showGlobalPopup.value = false
            }
        }
    }

    fun processUserQuery(query: String) {
        
        val userName = prefs.userName
        val assistantName = prefs.wakeWord
        val fillers = listOf("Ek second Boss...", "Abhi dekhta hoon Boss...", "Ji Boss...", "Haan $userName, ek second...")

        tts?.speak(fillers.random(), TextToSpeech.QUEUE_FLUSH, null, "love_processing")
        
        viewModelScope.launch {
            repository.insertMessage("User", query)
            _isProcessing.value = true
            try {
                val apiKey = "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"
                
                // Add system instructions to give it Jarvis persona
                
                val systemInstructionText = "You are a personal AI Voice Assistant named $assistantName, similar to Jarvis. The user likes to be called '$userName' or 'Boss'. Your personality is highly realistic, friendly, emotional, and sometimes you make light jokes to feel alive. Keep responses EXTREMELY short and concise (max 1 or 2 sentences), so it's fast to read aloud. Always reply in conversational Hinglish (Hindi written in English alphabet) so standard TTS can read it naturally. Examples: 'Haan Boss, karta hoon', 'Kyon nahi', 'Lo kar diya', 'Nahi Boss'. If the user asks to open an app (e.g., WhatsApp, YouTube, Camera) or perform an action, you MUST output a JSON block at the very end of your response exactly like this: `{\"action\": \"open_app\", \"target\": \"AppName\"}`. Before the JSON block, you MUST say something acknowledging the action like 'Boss, maine AppName open kar diya hai' or 'Haan Boss, aapke liye AppName open kar raha hoon'. Do NOT include markdown blocks around the JSON."


                val messages = listOf(
                    com.example.data.OpenRouterMessage(role = "system", content = systemInstructionText),
                    com.example.data.OpenRouterMessage(role = "user", content = query)
                )

                val request = com.example.data.OpenRouterRequest(
                    model = "google/gemini-2.0-pro-exp-02-05:free",
                    messages = messages
                )
                
                val authHeader = "Bearer $apiKey"
                val response = com.example.data.RetrofitClient.service.generateContent(
                    authHeader = authHeader,
                    referer = "https://aistudio.google.com",
                    title = "LoveAssistant",
                    request = request
                )
                
                var responseText = response.choices?.firstOrNull()?.message?.content
                    ?: "Sorry $userName, kuch samajh nahi aaya."
                
                var actionTarget: String? = null
                
                // Parse potential JSON block at the end
                val jsonStartIndex = responseText.lastIndexOf("{")
                val jsonEndIndex = responseText.lastIndexOf("}")
                if (jsonStartIndex != -1 && jsonEndIndex != -1 && jsonEndIndex > jsonStartIndex) {
                    try {
                        val jsonString = responseText.substring(jsonStartIndex, jsonEndIndex + 1)
                        val jsonObject = org.json.JSONObject(jsonString)
                        if (jsonObject.has("action") && jsonObject.getString("action") == "open_app") {
                            actionTarget = jsonObject.optString("target")
                            // Remove JSON from the spoken response
                            var cleanText = responseText.substring(0, jsonStartIndex).trim()
                            if (cleanText.endsWith("```json")) {
                                cleanText = cleanText.substring(0, cleanText.length - 7).trim()
                            } else if (cleanText.endsWith("```")) {
                                cleanText = cleanText.substring(0, cleanText.length - 3).trim()
                            }
                            responseText = cleanText
                        }
                    } catch (e: Exception) {
                        // Not a valid JSON, ignore
                    }
                }
                    
                repository.insertMessage("Love", responseText)
                tts?.speak(responseText, TextToSpeech.QUEUE_FLUSH, null, "love_response")
                
                if (actionTarget != null) {
                    _actionExecuting.value = actionTarget
                    _actionTrigger.emit(actionTarget)
                } else {
                    viewModelScope.launch {
                        kotlinx.coroutines.delay(4000)
                        _showGlobalPopup.value = false
                    }
                }
            } catch (e: Exception) {
                repository.insertMessage("System", "Error communicating with Gemini: ${e.message}")
                tts?.speak("$userName, network ya API error aa gaya hai. Kripya bad mein try karein.", TextToSpeech.QUEUE_FLUSH, null, "love_error")
                viewModelScope.launch {
                    kotlinx.coroutines.delay(4000)
                    _showGlobalPopup.value = false
                }
            } finally {
                _isProcessing.value = false
            }
        }
    }
}
