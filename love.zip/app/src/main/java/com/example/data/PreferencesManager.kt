package com.example.data

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("love_prefs", Context.MODE_PRIVATE)

    var wakeWord: String
        get() = prefs.getString("wake_word", "Love") ?: "Love"
        set(value) = prefs.edit().putString("wake_word", value).apply()

    var userName: String
        get() = prefs.getString("user_name", "Boss") ?: "Boss"
        set(value) = prefs.edit().putString("user_name", value).apply()

    var voiceResponses: Boolean
        get() = prefs.getBoolean("voice_responses", true)
        set(value) = prefs.edit().putBoolean("voice_responses", value).apply()

    var hotwordDetection: Boolean
        get() = prefs.getBoolean("hotword_detection", true)
        set(value) = prefs.edit().putBoolean("hotword_detection", value).apply()
}
