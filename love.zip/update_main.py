import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Remove the onResume / onPause hotword logic from MainActivity
content = re.sub(r'override fun onResume\(\).*?startInternalListening\(isHotword = true\)\s*\}\s*\}', r'override fun onResume() {\n      super.onResume()\n      isResumedState = true\n  }', content, flags=re.DOTALL)

# In startInternalListening, don't use isHotword
content = re.sub(r'private fun startInternalListening\(isHotword: Boolean\) \{', r'private fun startInternalListening() {', content)
content = re.sub(r'startInternalListening\(isHotword = (true|false)\)', r'startInternalListening()', content)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

