import re

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'r') as f:
    content = f.read()

content = content.replace("startActivity(launchIntent)", "isOverlayActive = true\n                        startActivity(launchIntent)")

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'w') as f:
    f.write(content)

