with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    lines = f.readlines()

count = 0
for i, line in enumerate(lines):
    # ignore comments for brace counting
    clean_line = line.split('//')[0]
    count += clean_line.count('{')
    count -= clean_line.count('}')
    if count <= 0 and '{' in clean_line or '}' in clean_line:
        print(f"Line {i+1}: {line.strip()} -> Depth: {count}")

