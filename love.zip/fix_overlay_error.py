import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

content = content.replace('tts?.speak("I didn\'t quite catch that, ${prefs.userName}.", TextToSpeech.QUEUE_FLUSH, null, null)', '')

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

