import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

replacement = """
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "overlay_ready") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            startInternalListening()
                        }
                    } else if (utteranceId == "love_response" || utteranceId == "love_error") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            finish()
                        }
                    }
                }
"""

content = re.sub(r'override fun onDone\(utteranceId: String\?\) \{.*?\}', replacement.strip(), content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

