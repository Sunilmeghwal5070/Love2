import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

glow_effect = """
            val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
            val glowAlpha by infiniteTransition.animateFloat(
                initialValue = 0.3f,
                targetValue = 0.8f,
                animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                    animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
                    repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
                ), label = "glowAlpha"
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Transparent)
            ) {
                // Left Edge
                Box(modifier = Modifier
                    .align(Alignment.CenterStart)
                    .androidx.compose.foundation.layout.width(16.dp)
                    .androidx.compose.foundation.layout.fillMaxHeight()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFFFF6FA5).copy(alpha = glowAlpha),
                                Color.Transparent
                            )
                        )
                    )
                )
                // Right Edge
                Box(modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .androidx.compose.foundation.layout.width(16.dp)
                    .androidx.compose.foundation.layout.fillMaxHeight()
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFFFF6FA5).copy(alpha = glowAlpha)
                            )
                        )
                    )
                )

                LoveAssistantPopup(
"""

content = content.replace("""            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Transparent)
            ) {
                LoveAssistantPopup(""", glow_effect)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

