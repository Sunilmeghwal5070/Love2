import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

replacement = """
            tts?.setPitch(1.0f)
            tts?.setSpeechRate(0.95f)
            
            tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "overlay_ready") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            startInternalListening()
                        }
                    }
                }
                override fun onError(utteranceId: String?) {
                    if (utteranceId == "overlay_ready") {
                        android.os.Handler(android.os.Looper.getMainLooper()).post {
                            startInternalListening()
                        }
                    }
                }
            })
            
            // Auto start listening on open
            tts?.speak("Yes ${prefs.userName}?", TextToSpeech.QUEUE_FLUSH, null, "overlay_ready")
        }
    }
"""

content = re.sub(r'tts\?\.setPitch\(1\.0f\).*?startInternalListening\(\)\n\s*\}\n\s*\}', replacement.strip() + "\n    }", content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

