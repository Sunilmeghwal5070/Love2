import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("                            \n                            viewModel.stopListening(null)", "                            viewModel.stopListening(null)\n                            finish()")

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

