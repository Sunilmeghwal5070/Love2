import re

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'r') as f:
    content = f.read()

content = content.replace("import androidx.compose.ui.graphics.Color", "import androidx.compose.ui.graphics.Color\nimport androidx.compose.animation.core.*\nimport androidx.compose.foundation.layout.width\nimport androidx.compose.foundation.layout.fillMaxHeight")

content = content.replace(".androidx.compose.foundation.layout.width(16.dp)", ".width(16.dp)")
content = content.replace(".androidx.compose.foundation.layout.fillMaxHeight()", ".fillMaxHeight()")

with open('app/src/main/java/com/example/ui/screens/LoveOverlayActivity.kt', 'w') as f:
    f.write(content)

