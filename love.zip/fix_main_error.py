import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

content = content.replace('tts?.speak("I didn\'t quite catch that, boss.", TextToSpeech.QUEUE_FLUSH, null, null)', '')

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)

