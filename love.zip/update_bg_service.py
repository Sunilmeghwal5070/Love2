import re

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'r') as f:
    content = f.read()

replacement = """
                override fun onResults(results: android.os.Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.lowercase() ?: ""
                    
                    val prefs = com.example.data.PreferencesManager(this@LoveBackgroundService)
                    val wakeWord = prefs.wakeWord.lowercase()
                    
                    if (text.contains(wakeWord) || text.contains("hello $wakeWord") || text.contains("hey $wakeWord") || text.contains("ok $wakeWord") || text.contains("hi $wakeWord")) {
                        Log.d("LoveBackgroundService", "Hotword detected!")
                        val launchIntent = Intent(this@LoveBackgroundService, LoveOverlayActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                        isOverlayActive = true
                        startActivity(launchIntent)
                    }
                    startListening()
                }

                override fun onPartialResults(partialResults: android.os.Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.lowercase() ?: ""
                    
                    val prefs = com.example.data.PreferencesManager(this@LoveBackgroundService)
                    val wakeWord = prefs.wakeWord.lowercase()
                    
                    if (text.contains(wakeWord) || text.contains("hello $wakeWord") || text.contains("hey $wakeWord") || text.contains("ok $wakeWord") || text.contains("hi $wakeWord")) {
                        speechRecognizer?.cancel()
                        val launchIntent = Intent(this@LoveBackgroundService, LoveOverlayActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                        isOverlayActive = true
                        startActivity(launchIntent)
                        isListening = false
                        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                            startListening()
                        }, 2000)
                    }
                }
"""

content = re.sub(r'override fun onResults\(.*?\).*?override fun onEvent', replacement + "\n                override fun onEvent", content, flags=re.DOTALL)

with open('app/src/main/java/com/example/assistant/LoveBackgroundService.kt', 'w') as f:
    f.write(content)

