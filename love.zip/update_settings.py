import re

with open('app/src/main/java/com/example/ui/screens/SettingsScreen.kt', 'r') as f:
    content = f.read()

replacement = """import androidx.compose.ui.platform.LocalContext
import com.example.data.PreferencesManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onNavigateBack: () -> Unit, onNavigateToPermissions: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { PreferencesManager(context) }
    
    var wakeWord by remember { mutableStateOf(prefs.wakeWord) }
    var userName by remember { mutableStateOf(prefs.userName) }
    var voiceResponses by remember { mutableStateOf(prefs.voiceResponses) }
    var hotwordDetection by remember { mutableStateOf(prefs.hotwordDetection) }
    var highQualityVoice by remember { mutableStateOf(true) }
"""

content = content.replace("""@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onNavigateBack: () -> Unit, onNavigateToPermissions: () -> Unit) {
    var voiceResponses by remember { mutableStateOf(true) }
    var hotwordDetection by remember { mutableStateOf(true) }
    var highQualityVoice by remember { mutableStateOf(true) }""", replacement)

content = content.replace("voiceResponses = it", "voiceResponses = it; prefs.voiceResponses = it")
content = content.replace("hotwordDetection = it", "hotwordDetection = it; prefs.hotwordDetection = it")

# add OutlinedTextFields for wake word and user name inside the AnimatedVisibility blocks
text_fields = """
                AnimatedVisibility(
                    visible = visible,
                    enter = slideInVertically(
                        initialOffsetY = { 50 },
                        animationSpec = spring(stiffness = Spring.StiffnessLow)
                    ) + fadeIn(),
                    exit = fadeOut()
                ) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.8f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            OutlinedTextField(
                                value = wakeWord,
                                onValueChange = { wakeWord = it; prefs.wakeWord = it },
                                label = { Text("Assistant Name / Wake Word") },
                                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedTextField(
                                value = userName,
                                onValueChange = { userName = it; prefs.userName = it },
                                label = { Text("Your Name (What to call you)") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }

                AnimatedVisibility(
                    visible = visible,
                    enter = slideInVertically(
                        initialOffsetY = { 75 },
                        animationSpec = spring(stiffness = Spring.StiffnessLow)
                    ) + fadeIn(),
                    exit = fadeOut()
                ) {"""

content = content.replace("""                AnimatedVisibility(
                    visible = visible,
                    enter = slideInVertically(
                        initialOffsetY = { 50 },
                        animationSpec = spring(stiffness = Spring.StiffnessLow)
                    ) + fadeIn(),
                    exit = fadeOut()
                ) {""", text_fields)

with open('app/src/main/java/com/example/ui/screens/SettingsScreen.kt', 'w') as f:
    f.write(content)

